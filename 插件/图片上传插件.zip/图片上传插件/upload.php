<?php
$f = json_encode($_FILES);
echo $f;
?>